# import libraries
import os
import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler
import joblib
import seaborn as sns
import pickle
sns.set(color_codes=True)
import matplotlib.pyplot as plt
import tensorflow as tf
tf.compat.v1.logging.set_verbosity(tf.compat.v1.logging.ERROR)
from keras.layers import Input, Dropout, Dense, LSTM, TimeDistributed, RepeatVector
from keras.models import Model
from keras import regularizers
# set random seed
tf.random.set_seed(10)
# to read MATLAB files
import scipy.io
from sklearn.metrics import roc_curve
from sklearn.metrics import roc_auc_score
from sklearn.metrics import plot_roc_curve
# Time
import time
start_time = time.time()
# Initialize panda dataframes
merged_train_data = pd.DataFrame()
merged_test_data = pd.DataFrame()

# load MATLAB DE training files
mat_train_DE_load_0 = scipy.io.loadmat('data/cwru/97.mat')
mat_train_DE_load_1 = scipy.io.loadmat('data/cwru/98.mat')
mat_train_DE_load_2 = scipy.io.loadmat('data/cwru/99.mat')
mat_train_DE_load_3 = scipy.io.loadmat('data/cwru/100.mat')

train_dataset_DE_load_0 = pd.DataFrame(mat_train_DE_load_0['X097_DE_time'])
train_dataset_DE_load_1 = pd.DataFrame(mat_train_DE_load_1['X098_DE_time'])
train_dataset_DE_load_2 = pd.DataFrame(mat_train_DE_load_2['X099_DE_time'])
train_dataset_DE_load_3 = pd.DataFrame(mat_train_DE_load_3['X100_DE_time'])

train_dataset_DE_load_0 = train_dataset_DE_load_0[:20000]
train_dataset_DE_load_1 = train_dataset_DE_load_1[:20000]
train_dataset_DE_load_2 = train_dataset_DE_load_2[:20000]
train_dataset_DE_load_3 = train_dataset_DE_load_3[:20000]

temp = pd.concat([train_dataset_DE_load_0, train_dataset_DE_load_1, train_dataset_DE_load_2, train_dataset_DE_load_3], axis=1)
merged_train_data = merged_train_data.append(temp)
merged_train_data.columns = ['load 0', 'load 1', 'load 2', 'load 3']

# load MATLAB DE test files
mat_test_DE_load_0 = scipy.io.loadmat('data/cwru/12k Drive End Bearing Fault Data/105.mat')
mat_test_DE_load_1 = scipy.io.loadmat('data/cwru/12k Drive End Bearing Fault Data/106.mat')
mat_test_DE_load_2 = scipy.io.loadmat('data/cwru/12k Drive End Bearing Fault Data/107.mat')
mat_test_DE_load_3 = scipy.io.loadmat('data/cwru/12k Drive End Bearing Fault Data/108.mat')

test_dataset_DE_load_0 = pd.DataFrame(mat_test_DE_load_0['X105_DE_time'])
test_dataset_DE_load_1 = pd.DataFrame(mat_test_DE_load_1['X106_DE_time'])
test_dataset_DE_load_2 = pd.DataFrame(mat_test_DE_load_2['X107_DE_time'])
test_dataset_DE_load_3 = pd.DataFrame(mat_test_DE_load_3['X108_DE_time'])

test_dataset_DE_load_0 = test_dataset_DE_load_0[:20000]
test_dataset_DE_load_1 = test_dataset_DE_load_1[:20000]
test_dataset_DE_load_2 = test_dataset_DE_load_2[:20000]
test_dataset_DE_load_3 = test_dataset_DE_load_3[:20000]

temp = pd.concat([test_dataset_DE_load_0, test_dataset_DE_load_1, test_dataset_DE_load_2, test_dataset_DE_load_3], axis=1)
merged_test_data = merged_test_data.append(temp)
merged_test_data.columns = ['load 0', 'load 1', 'load 2', 'load 3']

# transform data file index to datetime and sort in chronological order
# merged_data.index = pd.to_datetime(merged_data.index, format='%Y.%m.%d.%H.%M.%S')
# merged_data = merged_data.sort_index()
merged_train_data.to_csv('CWRU_DE_Training_Data.csv')
print("Dataset shape:", merged_train_data.shape)
merged_train_data.head()

train = merged_train_data
test = merged_test_data
print("Training dataset shape:", train.shape)
print("Test dataset shape:", test.shape)

"""
with open('merged_data_orig.pickle', 'wb') as f:
    pickle.dump(merged_data, f)

with open('original_data_orig.pickle', 'wb') as f:
    pickle.dump([train, test], f)
"""

fig, ax = plt.subplots(figsize=(14, 6), dpi=80)
ax.plot(train['load 0'], label='load 0', color='blue', linewidth=1)
ax.plot(train['load 1'], label='load 1', color='red', linewidth=1)
ax.plot(train['load 2'], label='load 2', color='green', linewidth=1)
ax.plot(train['load 3'], label='load 3', color='black', linewidth=1)
plt.legend(loc='lower left')
ax.set_title('Bearing Sensor Training Data', fontsize=16)
plt.show()

# transforming data from the time domain to the frequency domain using fast Fourier transform
train_fft = np.fft.fft(train)
test_fft = np.fft.fft(test)

# frequencies of the healthy sensor signal
fig, ax = plt.subplots(figsize=(14, 6), dpi=80)
ax.plot(train_fft[:, 0].real, label='load 1', color='blue', linewidth=1)
ax.plot(train_fft[:, 1].imag, label='load 2', color='red', linewidth=1)
ax.plot(train_fft[:, 2].real, label='load 3', color='green', linewidth=1)
ax.plot(train_fft[:, 3].real, label='load 4', color='black', linewidth=1)
plt.legend(loc='lower left')
ax.set_title('Bearing Sensor Training Frequency Data', fontsize=16)
plt.show()

# frequencies of the degrading sensor signal
fig, ax = plt.subplots(figsize=(14, 6), dpi=80)
ax.plot(test_fft[:, 0].real, label='load 1', color='blue', linewidth=1)
ax.plot(test_fft[:, 1].imag, label='load 2', color='red', linewidth=1)
ax.plot(test_fft[:, 2].real, label='load 3', color='green', linewidth=1)
ax.plot(test_fft[:, 3].real, label='load 4', color='black', linewidth=1)
plt.legend(loc='lower left')
ax.set_title('Bearing Sensor Test Frequency Data', fontsize=16)
plt.show()

# normalize the data
scaler = MinMaxScaler()
X_train = scaler.fit_transform(train)
X_test = scaler.transform(test)
scaler_filename = "scaler_data"
joblib.dump(scaler, scaler_filename)

# reshape inputs for LSTM [samples, timesteps, features]
X_train = X_train.reshape(X_train.shape[0], 1, X_train.shape[1])
print("Training data shape:", X_train.shape)
X_test = X_test.reshape(X_test.shape[0], 1, X_test.shape[1])
print("Test data shape:", X_test.shape)

"""
with open('modified_data_orig.pickle', 'wb') as f:
    pickle.dump([X_train, X_test], f)
"""

# define the autoencoder network model
def autoencoder_model(X):
    inputs = Input(shape=(X.shape[1], X.shape[2]))
    L1 = LSTM(8, activation='relu', return_sequences=True,
              kernel_regularizer=regularizers.l2(0.00))(inputs)
    L2 = LSTM(2, activation='relu', return_sequences=False)(L1)
    L3 = RepeatVector(X.shape[1])(L2)
    L4 = LSTM(2, activation='relu', return_sequences=True)(L3)
    L5 = LSTM(8, activation='relu', return_sequences=True)(L4)
    output = TimeDistributed(Dense(X.shape[2]))(L5)
    model = Model(inputs=inputs, outputs=output)
    return model

# create the autoencoder model
model = autoencoder_model(X_train)
model.compile(optimizer='adam', loss='mae')
model.summary()

# fit the model to the data
nb_epochs = 16
batch_size = 32
history = model.fit(X_train, X_train, epochs=nb_epochs, batch_size=batch_size,
                    validation_split=0.05).history

# plot the training losses
fig, ax = plt.subplots(figsize=(14, 6), dpi=80)
ax.plot(history['loss'], 'b', label='Train', linewidth=2)
ax.plot(history['val_loss'], 'r', label='Validation', linewidth=2)
ax.set_title('Model loss', fontsize=16)
ax.set_ylabel('Loss (mae)')
ax.set_xlabel('Epoch')
ax.legend(loc='upper right')
plt.show()

# calculate the loss on the test set
X_pred = model.predict(X_test)
X_pred = X_pred.reshape(X_pred.shape[0], X_pred.shape[2])
X_pred = pd.DataFrame(X_pred, columns=test.columns)
X_pred.index = test.index

scored_test = pd.DataFrame(index=test.index)
Xtest = X_test.reshape(X_test.shape[0], X_test.shape[2])
scored_test['Loss_mae'] = np.mean(np.abs(X_pred - Xtest), axis=1)
scored_test['Threshold'] = 0.128
scored_test['Anomaly'] = scored_test['Loss_mae'] > scored_test['Threshold']
scored_test.head()
plt.figure(figsize=(16, 9), dpi=80)
plt.title('Loss Distribution', fontsize=16)
sns.distplot(scored_test['Loss_mae'], bins=20, kde=True, color='blue')
plt.xlim([0.0, .5])
plt.show()

# and merge all data in a single dataframe for plotting
X_pred_train = model.predict(X_train)
X_pred_train = X_pred_train.reshape(X_pred_train.shape[0], X_pred_train.shape[2])
X_pred_train = pd.DataFrame(X_pred_train, columns=train.columns)
X_pred_train.index = train.index

scored_train = pd.DataFrame(index=train.index)
Xtrain = X_train.reshape(X_train.shape[0], X_train.shape[2])
scored_train['Loss_mae'] = np.mean(np.abs(X_pred_train - Xtrain), axis=1)
scored_train['Threshold'] = 0.128
scored_train['Anomaly'] = scored_train['Loss_mae'] > scored_train['Threshold']
# scored = pd.concat([scored_train, scored])

# Find optimal threshold using ROC Curve
scored = pd.concat([scored_train, scored_test])
loss_data = scored['Loss_mae'].to_numpy()
date_values = scored.index.to_numpy()

# trueLabel = np.copy(loss_data)
trueLabel = np.zeros(len(loss_data))
max_auc_each_date = np.zeros(len(loss_data))
threshold_values = np.zeros(len(loss_data))
auc_values = np.zeros(len(loss_data))
sorted_loss_data = np.sort(loss_data)
count = 0
# for i in sorted_loss_data: # For each date
     # trueLabel = loss_data
conjecture_failure_on_set_time = 20000
trueLabel[:conjecture_failure_on_set_time] = 0
trueLabel[conjecture_failure_on_set_time:] = 1
# Calculate roc curve
fpr, tpr, thresholds = roc_curve(trueLabel, loss_data)
# Calculate AUC
auc = roc_auc_score(trueLabel, loss_data)
# auc_values[count] = auc

optimal_index= np.argmax(tpr - fpr)
optimal_threshold = thresholds[optimal_index]

print("AUC = %3f and the optimal threshold = %.3f at index %d" %(auc, optimal_threshold, optimal_index))

with open('C:/Users/arjun.thangaraju/PycharmProjects/LSTM_Autoencoder_Anomaly_Detection/ROC_Saved_Values/CWRU_saved_values.pickle', 'wb') as f:
    pickle.dump([auc, optimal_threshold, optimal_index], f)

# Plot ROC Curve
plt.plot(fpr, tpr, color='g', marker='.', label='Logistic')
plt.legend("ROC Curve")
plt.title(" ROC Curve with AUC = %.3f" %auc)
plt.show()

# plot bearing failure time plot
index = optimal_index
scored['Threshold'] = optimal_threshold
print('Threshold value = %.5f' %optimal_threshold)
# plot bearing failure time plot
scored_train['Threshold'] = optimal_threshold
scored_test['Threshold'] = optimal_threshold
ax = scored_train.plot(logy=True, figsize=(16, 9), ylim=[1e-2, 1e2], color=['green', 'black'])
scored_test.plot(ax=ax, logy=True, figsize=(16, 9), ylim=[1e-2, 1e2], color=['red', 'black'])
plt.title(' Loss vs Threshold with Threshold value as %.5f' %optimal_threshold)
plt.show()

