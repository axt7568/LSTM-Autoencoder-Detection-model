# LSTM-Autoencoder-for-Anomaly-Detection
AI deep learning neural network for anomaly detection using Python, Keras and TensorFlow

This repository contains the code and data for the following Medium article:
https://towardsdatascience.com/lstm-autoencoder-for-anomaly-detection-e1f4f2ee7ccf?source=friends_link&sk=efc29d7bb24fbdfa4ac238f32e2abf7f
