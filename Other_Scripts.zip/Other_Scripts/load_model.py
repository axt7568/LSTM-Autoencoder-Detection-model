import pickle
import seaborn as sns
import matplotlib.pyplot as plt

with open('scored_big.pickle', 'rb') as f:
    scored = pickle.load(f)

# Change scored threshold value
scored.Threshold = 0.07

"""
# Plot Loss Distribution
plt.figure(figsize=(16, 9), dpi=80)
plt.title('Loss Distribution', fontsize=16)
sns.distplot(scored['Loss_mae'], bins=20, kde=True, color='blue');
plt.xlim([0.0, .5])
plt.show()
"""

# plot bearing failure time plot
plt.rc('xtick',labelsize=7)
scored.plot(logy=True, figsize=(16, 16), ylim=[1e-4, 1e2], color=['blue', 'red'])
plt.title("Loss VS Threshold Plot for 12 features(MAE + STD + BandPower); Threshold = 0.23")
plt.show()