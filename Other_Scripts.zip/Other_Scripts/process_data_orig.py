# import libraries
import os
import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler
import joblib
import seaborn as sns

sns.set(color_codes=True)
import matplotlib.pyplot as plt
import tensorflow as tf

tf.compat.v1.logging.set_verbosity(tf.compat.v1.logging.ERROR)
from keras.layers import Input, Dropout, Dense, LSTM, TimeDistributed, RepeatVector
from keras.models import Model
from keras import regularizers
import pickle

# set random seed
tf.random.set_seed(10)

# load, average and merge sensor samples
data_dir = 'data/bearing_data'
merged_data = pd.DataFrame()

# Initialize variables used
sampling_rate = 20479
timestep = 1 / sampling_rate
freq_start = 3000
freq_end = 5000

for filename in os.listdir(data_dir):
    dataset = pd.read_csv(os.path.join(data_dir, filename), sep='\t')
    dataset_mean_abs = np.array(dataset.abs().mean(axis=0))  # Absolute Mean Value
    # Reshape and Concat Data Frame
    dataset_mean_abs = pd.DataFrame(dataset_mean_abs.reshape(1, 4))
    temp = pd.concat([dataset_mean_abs], axis=1)
    temp.index = [filename]
    merged_data = merged_data.append(temp)

merged_data.columns = ['Bearing 1 MeanABS',
                       'Bearing 2 MeanABS',
                       'Bearing 3 MeanABS',
                       'Bearing 4 MeanABS']

# transform data file index to datetime and sort in chronological order
# merged_data.index = pd.to_datetime(merged_data.index, format='%Y.%m.%d.%H.%M.%S')
# merged_data = merged_data.sort_index()

# merged_data.to_csv('Averaged_STD_BandPower_BearingTest_Dataset.csv')
merged_data.to_csv('Averaged_ABS_BearingTest_Dataset.csv')
print("Dataset shape:", merged_data.shape)
merged_data.head()

# train = merged_data["2004.02.12.10.52.39":"2004.02.15.12.52.39"]

sample_size = len(merged_data.index)
good_data_num = (int)(sample_size/2)
bad_data_num = sample_size - good_data_num

"""
# Check Data sizes
print("sample size is ", sample_size)
print("good data num ", good_data_num)
print("bad data num", bad_data_num)
"""

train = merged_data.head(good_data_num)
test = merged_data.tail(bad_data_num)
print("Training dataset shape:", train.shape)
print("Test dataset shape:", test.shape)

plt.rc('xtick', labelsize=7)

# Put print statements here

# normalize the data
scaler = MinMaxScaler()
X_train = scaler.fit_transform(train)
X_test = scaler.transform(test)
scaler_filename = "scaler_data"
joblib.dump(scaler, scaler_filename)

# reshape inputs for LSTM [samples, timesteps, features]
X_train = X_train.reshape(X_train.shape[0], 1, X_train.shape[1])
print("Training data shape:", X_train.shape)
X_test = X_test.reshape(X_test.shape[0], 1, X_test.shape[1])
print("Test data shape:", X_test.shape)

with open('pickle_files/orig_mod_data.pickle', 'wb') as f:
    pickle.dump([merged_data, train, test, X_train, X_test], f)

