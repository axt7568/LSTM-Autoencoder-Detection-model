import pickle
import seaborn as sns
import matplotlib.pyplot as plt
from keras.models import load_model
import pandas as pd
import numpy as np
import numpy as np
import matplotlib.pyplot as plt
from sklearn import metrics
from statistics import mean

def pdf(x, std, mean):
    const = 1.0 / np.sqrt(2 * np.pi * (std ** 2))
    pdf_normal_dist = const * np.exp(-((x - mean) ** 2) / (2.0 * (std ** 2)))
    return pdf_normal_dist

def plot_pdf(good_pdf, bad_pdf, ax):
    ax.fill(x, good_pdf, "g", alpha=0.5)
    ax.fill(x, bad_pdf, "r", alpha=0.5)
    ax.set_xlim([-30, 30])
    ax.set_ylim([-20, 20])
    ax.set_title("Probability Distribution", fontsize=14)
    ax.set_ylabel('Density', fontsize=12)
    ax.set_xlabel('P(X)', fontsize=12)
    ax.legend(["Class One - Good Data", "Class Two - Bad Data"])

def plot_roc(good_pdf, bad_pdf, ax, color):
    # Total
    total_bad = np.sum(bad_pdf)
    total_good = np.sum(good_pdf)
    # Cummulative sum
    cum_TP = 0
    cum_FP = 0
    # TPR and FPR list initialization
    TPR_list = []
    FPR_list = []
    # Iterate through all values of x
    for i in range(len(x)):
        # We are only interested in non-zero values of bad
        if bad_pdf[i] > 0:
            cum_TP += bad_pdf[len(x) - 1 - i]
            cum_FP += good_pdf[len(x) - 1 - i]
        FPR = cum_FP / total_good
        TPR = cum_TP / total_bad
        TPR_list.append(TPR)
        FPR_list.append(FPR)
    # Calculating AUC, taking the 100 timesteps into account
    auc = metrics.auc(FPR_list, TPR_list)
    plot_final_roc(x, FPR_list, TPR_list, auc, ax, color)
    return auc

def plot_final_roc(x, FPR_list, TPR_list, auc, ax, color):
    # Plotting final ROC curve
    ax.plot(FPR_list, TPR_list, color)
    ax.plot(x, x, "--r")
    ax.set_xlim([0, 1])
    ax.set_ylim([0, 1])
    ax.set_title("ROC Cruve", fontsize=14)
    ax.set_ylabel('TPR', fontsize=12)
    ax.set_xlabel('FPR', fontsize=12)
    ax.grid()
    # print(auc)
    ax.legend(["AUC=%.3f" % auc])

with open('original_data.pickle', 'rb') as f:
    [train, test] = pickle.load(f)

with open('modified_data.pickle', 'rb') as f:
    [X_train, X_test] = pickle.load(f)

# Load h5 model
model = load_model('Cloud_model.h5')

model.summary()

# calculate the loss on the training set
X_pred = model.predict(X_train)
X_pred = X_pred.reshape(X_pred.shape[0], X_pred.shape[2])
X_pred = pd.DataFrame(X_pred, columns=train.columns)
X_pred.index = train.index
scored_train = pd.DataFrame(index=train.index)
Xtrain = X_train.reshape(X_train.shape[0], X_train.shape[2])
scored_train['Loss_mae'] = np.mean(np.abs(X_pred - Xtrain), axis=1)

# calculate the loss on the test set
X_pred = model.predict(X_test)
X_pred = X_pred.reshape(X_pred.shape[0], X_pred.shape[2])
X_pred = pd.DataFrame(X_pred, columns=test.columns)
X_pred.index = test.index
scored_test = pd.DataFrame(index=test.index)
Xtest = X_test.reshape(X_test.shape[0], X_test.shape[2])
scored_test['Loss_mae'] = np.mean(np.abs(X_pred - Xtest), axis=1)
"""
scored_train['Threshold'] = 0.22
scored_train['Anomaly'] = scored_train['Loss_mae'] > scored_train['Threshold']
"""
scored = pd.concat([scored_train, scored_test])
# scored = scored_train
scored['Threshold'] = 0.22
scored['Anomaly'] = scored['Loss_mae'] > scored['Threshold']
loss_data = scored['Loss_mae'].tolist()
x = loss_data
for i in range (1,len(loss_data)):
    conjecture_failure_on_set_time = i
    good_data = loss_data[:conjecture_failure_on_set_time]
    bad_data = loss_data[conjecture_failure_on_set_time:]
    # for j in loss_data:
    # Good Data Metrics
    mean_good_data = np.mean(good_data)
    std_good_data = np.std(good_data)
    # Bad Data Metrics
    mean_bad_data = np.mean(bad_data)
    std_bad_data = np.std(bad_data)
    # Individual Plots
    fig, ax = plt.subplots(1, 2, figsize=(10, 5))
    # plot pdf curve
    # Class 1 vs Class 2
    plot_pdf(pdf(x, mean_good_data, std_good_data), pdf(x, mean_bad_data, std_bad_data), ax[0])
    # plot roc curve
    lstm_roc = plot_roc(pdf(x, mean_good_data, std_good_data), pdf(x, mean_bad_data, std_bad_data), ax[1], "orange")
    plt.legend(["PCA; AUC=%.4f" % lstm_roc])
    plt.tight_layout()
    # plt.show()
    # Print Statements
    print("PCA AUC = %.4f for index %d" %(lstm_roc, i))
    plt.close(fig)
"""
# plot the loss distribution of the test set
plt.figure(figsize=(16, 9), dpi=80)
plt.title('Loss Distribution for  for 12-24-16-8-4 model', fontsize=16)
sns.distplot(scored['Loss_mae'], bins=20, kde=True, color='blue')
plt.xlim([0.0, .5])
plt.show()

# plot bearing failure time plot
scored.plot(logy=True, figsize=(16, 16), ylim=[1e-2, 1e2], color=['blue', 'red'])
plt.title(' Loss vs Threshold for  for 12-24-16-8-4 model; Threshold - 0.22')
plt.show()
"""