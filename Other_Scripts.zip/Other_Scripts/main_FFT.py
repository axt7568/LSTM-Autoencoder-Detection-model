# import libraries
import os
import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler
import joblib
import seaborn as sns
sns.set(color_codes=True)
import matplotlib.pyplot as plt
import tensorflow as tf
tf.compat.v1.logging.set_verbosity(tf.compat.v1.logging.ERROR)
from keras.layers import Input, Dropout, Dense, LSTM, TimeDistributed, RepeatVector
from keras.models import Model
from keras import regularizers


# load, average and merge sensor samples
data_dir = 'data/bearing_data'
# data_dir = 'data/40HzData'


# Plot Specific Frequencies
# 02/15 - Before it Fails
# 02/16 - Just Before it Fails
# 02/17 - Just After it Fails
# 02/19 - After It Fails

"""
# Test 
dataset_before_it_fails = pd.read_csv(os.path.join(data_dir, "40HzData3"), sep='\t')
dataset_before_it_fails.columns=['Bearing 1', 'Bearing 2', 'Bearing 3', 'Bearing 4']
"""

# dataset_before_it_fails = pd.read_csv(os.path.join(data_dir, "2004.02.15.00.02.39"), sep='\t')
# dataset_before_it_fails.columns=['Bearing 1', 'Bearing 2', 'Bearing 3', 'Bearing 4']

dataset_before_it_fails = pd.read_csv(os.path.join(data_dir, "2004.02.16.00.02.39"), sep='\t')
dataset_before_it_fails.columns=['Bearing 1', 'Bearing 2', 'Bearing 3', 'Bearing 4']
# dataset_2_16.columns = pd.read_csv(os.path.join(data_dir, "2004.02.16.00.02.39"), sep='\t')
# dataset_2_16.columns = ['Bearing 1', 'Bearing 2', 'Bearing 3', 'Bearing 4']

"""
dataset_2_17 = pd.read_csv(os.path.join(data_dir, "2004.02.17.00.02.39"), sep='\t')
dataset_2_17.columns=['Bearing 1', 'Bearing 2', 'Bearing 3', 'Bearing 4']

dataset_after_it_fails = pd.read_csv(os.path.join(data_dir, "2004.02.19.06.22.39"), sep='\t')
dataset_after_it_fails.columns=['Bearing 1', 'Bearing 2', 'Bearing 3', 'Bearing 4']
"""

print("Dataset shape:", dataset_before_it_fails.shape)

dataset_before_it_fails_fft = np.fft.fft(dataset_before_it_fails['Bearing 1'])
n = dataset_before_it_fails_fft.size
sampling_rate = 20479
timestep = 1/sampling_rate
freq = np.fft.fftfreq(n, d=timestep)
# freq = sampling_rate * norm_freq
amp = np.absolute(dataset_before_it_fails_fft)
# Plot Graph
fig, ax = plt.subplots(1, 1, figsize=(14, 5))
ax.plot(freq, amp, "r")


dataset_before_it_fails_fft = np.fft.fft(dataset_before_it_fails['Bearing 2'])
n = dataset_before_it_fails_fft.size
sampling_rate = 20479
timestep = 1/sampling_rate
freq = np.fft.fftfreq(n, d=timestep)
# freq = sampling_rate * norm_freq
amp = np.absolute(dataset_before_it_fails_fft)
# Plot Graph
# fig, ax = plt.subplots(1, 1, figsize=(14, 5))
ax.plot(freq, amp, "g")


dataset_before_it_fails_fft = np.fft.fft(dataset_before_it_fails['Bearing 3'])
n = dataset_before_it_fails_fft.size
sampling_rate = 20479
timestep = 1/sampling_rate
freq = np.fft.fftfreq(n, d=timestep)
# freq = sampling_rate * norm_freq
amp = np.absolute(dataset_before_it_fails_fft)
# Plot Graph
# fig, ax = plt.subplots(1, 1, figsize=(14, 5))
ax.plot(freq, amp, "b")

dataset_before_it_fails_fft = np.fft.fft(dataset_before_it_fails['Bearing 4'])
n = dataset_before_it_fails_fft.size
sampling_rate = 20479
timestep = 1/sampling_rate
freq = np.fft.fftfreq(n, d=timestep)
# freq = sampling_rate * norm_freq
amp = np.absolute(dataset_before_it_fails_fft)
# Plot Graph
# fig, ax = plt.subplots(1, 1, figsize=(14, 5))
ax.plot(freq, amp, "orange")


ax.set_title("Frequency vs Amplitude after it fails on 02/19")
ax.set_xlabel("Frequency")
ax.set_ylabel("Amplitude")
ax.grid()
ax.legend(["Bearing 1", "Bearing 2", "Bearing 3", "Bearing 4"])
plt.show()

"""

dataset_before_it_fails_fft = np.fft.fft(dataset_before_it_fails['Bearing 1'])
n = dataset_before_it_fails.size
sampling_rate = 20479
timestep = 1/sampling_rate
freq = np.fft.fftfreq(n, d=timestep)
amp = sampling_rate * freq
# Plot Graph
fig, ax = plt.subplots(1, 1, figsize=(14, 5))
ax.plot(freq, amp, "r")
ax.set_title("Frequency vs Amplitude")
ax.set_xlabel("Frequency")
ax.set_ylabel("Amplitude")
ax.grid()
ax.legend(["Bearing 1"])
plt.show()


dataset_before_it_fails_fft = np.fft.fft(dataset_before_it_fails['Bearing 2'])
n = dataset_before_it_fails.size
sampling_rate = 20479
timestep = 1/sampling_rate
freq = np.fft.fftfreq(n, d=timestep)
amp = sampling_rate * freq
# Plot Graph
fig, ax = plt.subplots(1, 1, figsize=(14, 5))
ax.plot(freq, amp, "r")
ax.set_title("Frequency vs Amplitude")
ax.set_xlabel("Frequency")
ax.set_ylabel("Amplitude")
ax.grid()
ax.legend(["Bearing 1"])
plt.show()

dataset_before_it_fails_fft = np.fft.fft(dataset_before_it_fails['Bearing 3'])
n = dataset_before_it_fails.size
sampling_rate = 20479
timestep = 1/sampling_rate
freq = np.fft.fftfreq(n, d=timestep)
amp = sampling_rate * freq
# Plot Graph
fig, ax = plt.subplots(1, 1, figsize=(14, 5))
ax.plot(freq, amp, "r")
ax.set_title("Frequency vs Amplitude")
ax.set_xlabel("Frequency")
ax.set_ylabel("Amplitude")
ax.grid()
ax.legend(["Bearing 1"])
plt.show()

dataset_before_it_fails_fft = np.fft.fft(dataset_before_it_fails['Bearing 4'])
n = dataset_before_it_fails.size
sampling_rate = 20479
timestep = 1/sampling_rate
freq = np.fft.fftfreq(n, d=timestep)
amp = sampling_rate * freq
# Plot Graph
fig, ax = plt.subplots(1, 1, figsize=(14, 5))
ax.plot(freq, amp, "r")
ax.set_title("Frequency vs Amplitude")
ax.set_xlabel("Frequency")
ax.set_ylabel("Amplitude")
ax.grid()
ax.legend(["Bearing 1"])
plt.show()

"""