import numpy as np
import matplotlib.pyplot as plt
from sklearn import metrics

def pdf(x, std, mean):
    const = 1.0 / np.sqrt(2 * np.pi * (std ** 2))
    pdf_normal_dist = const * np.exp(-((x - mean) ** 2) / (2.0 * (std ** 2)))
    return pdf_normal_dist

def plot_pdf(good_pdf, bad_pdf, ax):
    ax.fill(x, good_pdf, "g", alpha=0.5)
    ax.fill(x, bad_pdf, "r", alpha=0.5)
    ax.set_xlim([0, 30])
    ax.set_ylim([0, 20])
    ax.set_title("Probability Distribution", fontsize=14)
    ax.set_ylabel('Density', fontsize=12)
    ax.set_xlabel('P(X)', fontsize=12)
    ax.legend(["Class One - Good Data", "Class Two - Bad Data"])

def plot_roc(good_pdf, bad_pdf, ax, color):
    # Total
    total_bad = np.sum(bad_pdf)
    total_good = np.sum(good_pdf)
    # Cummulative sum
    cum_TP = 0
    cum_FP = 0
    # TPR and FPR list initialization
    TPR_list = []
    FPR_list = []
    # Iterate through all values of x
    for i in range(len(x)):
        # We are only interested in non-zero values of bad
        if bad_pdf[i] > 0:
            cum_TP += bad_pdf[len(x) - 1 - i]
            cum_FP += good_pdf[len(x) - 1 - i]
        FPR = cum_FP / total_good
        TPR = cum_TP / total_bad
        TPR_list.append(TPR)
        FPR_list.append(FPR)
    # Calculating AUC, taking the 100 timesteps into account
    auc = metrics.auc(FPR_list, TPR_list)
    plot_final_roc(x, FPR_list, TPR_list, auc, ax, color)
    return auc

def plot_final_roc(x, FPR_list, TPR_list, auc, ax, color):
    # Plotting final ROC curve
    ax.plot(FPR_list, TPR_list, color)
    ax.plot(x, x, "--r")
    ax.set_xlim([0, 1])
    ax.set_ylim([0, 1])
    ax.set_title("ROC Cruve", fontsize=14)
    ax.set_ylabel('TPR', fontsize=12)
    ax.set_xlabel('FPR', fontsize=12)
    ax.grid()
    # print(auc)
    ax.legend(["AUC=%.3f" % auc])

# Individual Plots
x = np.linspace(-30, 30, 1000)
fig, ax = plt.subplots(1, 2, figsize=(10, 5))

# plot pdf curve
# Class 2 vs Class 3
plot_pdf(pdf(x, 0.03, 0.07), pdf(x, 3.45, 2.34), ax[0])

# plot roc curve
lstm_roc = plot_roc(pdf(x, 0.03, 0.07), pdf(x, 3.45, 2.34), ax[1], "orange")

plt.legend(["PCA; AUC=%.4f" % lstm_roc])

plt.tight_layout()
plt.show()

# Print Statements
print("PCA AUC = %.4f" %lstm_roc)
