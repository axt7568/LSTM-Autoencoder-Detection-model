# import libraries
import pandas as pd
import numpy as np
import seaborn as sns
sns.set(color_codes=True)
import matplotlib.pyplot as plt
import tensorflow as tf
tf.compat.v1.logging.set_verbosity(tf.compat.v1.logging.ERROR)
import pickle
from keras.models import load_model
from sklearn import datasets
import matplotlib.pyplot as plt
import numpy as np
from scipy.stats import  norm
import pickle

# Load saved model
model = load_model('model_6_56_pm.h5')

with open('original_data.pickle', 'rb') as f:
    [train, test] = pickle.load(f)

with open('modified_data.pickle', 'rb') as f:
    [X_train, X_test] = pickle.load(f)

model.summary()

# plot the loss distribution of the training set
X_pred = model.predict(X_train)
X_pred = X_pred.reshape(X_pred.shape[0], X_pred.shape[2])
X_pred = pd.DataFrame(X_pred, columns=train.columns)
X_pred.index = train.index

X_pred_test = model.predict(X_test)
X_pred_test = X_pred_test.reshape(X_pred_test.shape[0], X_pred_test.shape[2])
X_pred_test = pd.DataFrame(X_pred_test, columns=test.columns)
X_pred_test.index = test.index

scored = pd.DataFrame(index=train.index)
Xtrain = X_train.reshape(X_train.shape[0], X_train.shape[2])
scored['Loss_mae'] = np.mean(np.abs(X_pred - Xtrain), axis=1)

scored_test = pd.DataFrame(index=test.index)
Xtest = X_test.reshape(X_test.shape[0], X_test.shape[2])
scored_test['Loss_mae'] = np.mean(np.abs(X_pred_test - Xtest), axis=1)

"""
# Plot Loss Distribution for good and bad data
plt.figure(figsize=(16, 9), dpi=80)
plt.title('Loss Distribution for  for 12-24-16-8-4 model', fontsize=16)
sns.distplot(scored['Loss_mae'], bins=10, kde=True, color='blue')
sns.distplot(scored_test['Loss_mae'], bins=500, kde=True, color='red')
plt.xlim([-10, 10])
"""

mod_list = [scored['Loss_mae'], scored_test['Loss_mae']]
colors = ['r', 'g', 'b']
labels = ["Good Data", "Bad Data"]
# Variable i is used to select the class
#
# 0 - CLass 1 : Good Data
# 1 - Class 2 : Bad Data
i = 1
# for data in mod_list:
"""
# Fit to original distribution
sns.distplot(data)
sns.distplot(data, fit=norm, kde=False)
plt.show()
"""
data = mod_list[i]
# Fit a normal distribution to the data:
mu, std = norm.fit(data)
# Plot the histogram.
plt.hist(data, bins=25, density=True, alpha=0.6, color=colors[i])
# Plot the PDF.
xmin, xmax = plt.xlim()
x = np.linspace(xmin, xmax, 100)
p = norm.pdf(x, mu, std)
# plt.plot(x, p,colors[i], linewidth=2, label=labels[i])
sns.distplot(data, bins=10, kde=True, color=colors[i], label=labels[i])
title = "Fit results: mu = %.2f,  sd = %.2f" % (mu, std)
plt.legend(loc='best')
plt.title("Loss Distribution; " + title)
plt.xlabel("Loss MAE")
plt.ylabel("Density")
plt.show()
